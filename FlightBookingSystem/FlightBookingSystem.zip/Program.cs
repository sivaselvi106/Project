﻿using System.Configuration;

namespace FlightBookingSystem
{
    class Program
    {
        internal static string adminLogin = ConfigurationManager.AppSettings["MailId"].ToString();
        internal static string adminPassword = ConfigurationManager.AppSettings["password"].ToString();
        static void Main()
            {
             EntryPortal.PortalEntry();
        }
    }
}
