﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace UserDetails
{
    class UserManager
    {
      public void AddUserDetails(SqlConnection connection)
        {

            Console.Write("Enter username: ");
            string userName = Console.ReadLine();
            Console.Write("Enter user mail id: ");
            string mailId = Console.ReadLine();
            Console.Write("Enter user mob no: ");
            string mobNo = Console.ReadLine();
            Console.Write("Enter role: ");
            string role = Console.ReadLine();
            SqlCommand sqlCommand = new SqlCommand("INSERTUSER", connection);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@userName", userName);
            sqlCommand.Parameters.AddWithValue("@mailId", mailId);
            sqlCommand.Parameters.AddWithValue("@mobNo", mobNo);
            sqlCommand.Parameters.AddWithValue("@userrole", role);
            int i = sqlCommand.ExecuteNonQuery();
            if (i > 0)
            {
                Console.WriteLine("Inserted successfully!!!");
            }

            //Using Parameter 
            //string insertValue = "INSERT INTO USERDETAIL (USERNAME,MAILID,MOBNO,USERROLE) VALUES(@userName,@mailId,@mobNo,@role)";
            //SqlCommand sqlCommand = new SqlCommand(insertValue, connection);
            //sqlCommand.Parameters.AddWithValue("@userName", userName);
            //sqlCommand.Parameters.AddWithValue("@mailId", mailId);
            //sqlCommand.Parameters.AddWithValue("@mobNo", mobNo);
            //sqlCommand.Parameters.AddWithValue("@role", role);
            //sqlCommand.ExecuteNonQuery();

            //Using data adapter
            //string insertValue = "Insert Into Train(UserName, MailId, MobNo, Role)" +
            //    "Values('" + userName + "', ' " + mailId + "', ' " + mobNo + "', ' " + role + "'" +  ")";

            //SqlDataAdapter dataAdapter = new SqlDataAdapter
            //{
            //    InsertCommand = new SqlCommand(insertValue, connection)
            //};
            //dataAdapter.InsertCommand.ExecuteNonQuery();
        }
        public void DisplayUserDetail(SqlConnection connection)
        {

            //Using stored procedure
            SqlCommand sqlCommand = new SqlCommand("DISPLAYUSER", connection);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            SqlDataReader reader = sqlCommand.ExecuteReader();
            if (reader.HasRows)
            {
               while (reader.Read())
                {
                    Console.WriteLine("UserName: {0}\nMailId: {1}\nMobNo: {2}\nRole: {3}",reader.GetString(0),reader.GetString(1),reader.GetString(2),reader.GetString(3));
                }
            }
            else
            {
                Console.WriteLine("No rows found.");
            }
            reader.Close();

            //Using DataReader
            //   string display = "SELECT USERNAME,MAILID,MOBNO,USERROLE FROM USERDETAIL";
            //    SqlCommand sqlCommand = new SqlCommand(display, connection);
            //    SqlDataReader reader = sqlCommand.ExecuteReader();
            //    if (reader.HasRows)
            //    {
            //        while (reader.Read())
            //        {
            //            Console.WriteLine("USERNAME: {0}\nMAILID: {1}\nMOBNO: {2}\nROLE: {3}", reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3));
            //        }
            //    }
            //    else
            //    {
            //        Console.WriteLine("No rows found.");
            //    }
            //    reader.Close();

            //Using DataAdapter
            //try
            //{
            //    string sqlDisplay = "SELECT * FROM USERDETAIL";
            //    SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlDisplay, connection);
            //    DataTable table = new DataTable();
            //    dataAdapter.Fill(table);
            //    foreach (DataRow row in table.Rows)
            //    {
            //        foreach (DataColumn column in table.Columns)
            //        {
            //            Console.WriteLine(row[column] + "\n");
            //        }
            //    }
            //}
            //catch (Exception e)
            //{

            //    Console.WriteLine(e.Message);
            //}

        }
        public void UpdateUserDetail(SqlConnection connection)
        {
            string status;
            do
            {
                Console.WriteLine("Enter the field to be updated: \n1.Username\n2.MobNo\n3.Role");
                byte choice = Byte.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        UpdateUserName(connection);
                        break;
                    case 2:
                        UpdateUserMobNo(connection);
                        break;
                    case 3:
                        UpdateUserRole(connection);
                        break;
                }
                Console.WriteLine("Do you want to continue[yes/no]: ");
                status = Console.ReadLine().ToLower();
            } while (status == "yes");
        }
        public void UpdateUserName(SqlConnection connection)
        {
            Console.WriteLine("Enter the mail id");
            string mailId = Console.ReadLine();
            Console.WriteLine("Enter the updated name: ");
            String userName = Console.ReadLine();
            SqlCommand command = new SqlCommand("UPDATEUSERNAME", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add("@MAILID", SqlDbType.VarChar);
            command.Parameters.Add("@USERNAME", SqlDbType.VarChar);
            command.Parameters["@MAILID"].Value = mailId;
            command.Parameters["@USERNAME"].Value = userName;
            int i = command.ExecuteNonQuery();
            if (i > 0)
            {
                Console.WriteLine("User name updated successfully!!!");
            }

            //Using parameter

            //string updateUser = "UPDATE USERDETAIL SET USERNAME = @userName WHERE MAILID = @mailId;";
            //SqlCommand command = new SqlCommand(updateUser, connection);
            //command.Parameters.Add("@MAILID", SqlDbType.VarChar);
            //command.Parameters.Add("@USERNAME",SqlDbType.VarChar);
            //command.Parameters["@MAILID"].Value = mailId;
            //command.Parameters["@USERNAME"].Value = userName;
            //command.ExecuteNonQuery();

            //Using DataAdapter
            //try
            //{
            //    string updateUser = "UPDATE USERDETAIL SET USERNAME = '" + userName + "' WHERE MAILID = '" + mailId + "';";
            //    SqlDataAdapter adapter = new SqlDataAdapter();
            //    adapter.UpdateCommand = connection.CreateCommand();
            //    adapter.UpdateCommand.CommandText = updateUser;
            //    adapter.UpdateCommand.ExecuteNonQuery();
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}


        }
        public void UpdateUserMobNo(SqlConnection connection)
        {
            Console.WriteLine("Enter the mail id");
            string mailId = Console.ReadLine();
            Console.WriteLine("Enter the updated mob no: ");
            String mobNo = Console.ReadLine();
            SqlCommand command = new SqlCommand("UPDATEUSERMOBNO", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add("@MAILID", SqlDbType.VarChar);
            command.Parameters.Add("@MOBNO", SqlDbType.VarChar);
            command.Parameters["@MAILID"].Value = mailId;
            command.Parameters["@MOBNO"].Value = mobNo;
            int i = command.ExecuteNonQuery();
            if (i > 0)
            {
                Console.WriteLine("User mob no updated successfully!!!");
            }
            //Parameter
            //string updateUser = "UPDATE USERDETAIL SET MOBNO = @mobNo WHERE MAILID = @mailId;";
            //SqlCommand command = new SqlCommand(updateUser, connection);
            //command.Parameters.Add("@MAILID", SqlDbType.VarChar);
            //command.Parameters.Add("@MOBNO", SqlDbType.VarChar);
            //command.Parameters["@MAILID"].Value = mailId;
            //command.Parameters["@MOBNO"].Value = mobNo;
            //command.ExecuteNonQuery();

            //DataAdapter
            //try
            //{
            //    string updateUser = "UPDATE USERDETAIL SET MOBNO = '" + mobNo + "' WHERE MAILID = '" + mailId + "';";
            //    SqlDataAdapter adapter = new SqlDataAdapter();
            //    adapter.UpdateCommand = connection.CreateCommand();
            //    adapter.UpdateCommand.CommandText = updateUser;                                                                                                                                                                          
            //    adapter.UpdateCommand.ExecuteNonQuery();
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
        }
        public void UpdateUserRole(SqlConnection connection)
        {
            Console.WriteLine("Enter the mail id");
            string mailId = Console.ReadLine();
            Console.WriteLine("Enter the updated mail id: ");
            String role = Console.ReadLine();
            SqlCommand command = new SqlCommand("UPDATEUSERROLE", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add("@MAILID", SqlDbType.VarChar);
            command.Parameters.Add("@USERROLE",SqlDbType.VarChar);
            command.Parameters["@MAILID"].Value = mailId;
            command.Parameters["@USERROLE"].Value = role;
            int i = command.ExecuteNonQuery();
            if (i > 0)
            {
                Console.WriteLine("User role updated successfully!!!");
            }

            ////Parameter
            //string updateUser = "UPDATE USERDETAIL SET USERROLE = @role WHERE MAILID = @mailId";
            //SqlCommand command = new SqlCommand(updateUser, connection);
            //command.Parameters.Add("@MAILID",SqlDbType.VarChar);
            //command.Parameters.Add("@USERROLE", System.Data.SqlDbType.VarChar);
            //command.Parameters["@MAILID"].Value = mailId;
            //command.Parameters["@USERROLE"].Value = role;
            //command.ExecuteNonQuery();

            //DataAdapter
            //try
            //{
            //    string updateUser = "UPDATE USERDETAIL SET ROLE = '" + role + "' WHERE MAILID = '" + mailId + "';";
            //    SqlDataAdapter adapter = new SqlDataAdapter();
            //    adapter.UpdateCommand = connection.CreateCommand();
            //    adapter.UpdateCommand.CommandText = updateUser;
            //    adapter.UpdateCommand.ExecuteNonQuery();
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

        }
        public void DeleteUserDetail(SqlConnection connection)
        {
            Console.WriteLine("Enter the mail id to delete the user: ");
            string mailId = Console.ReadLine();
            SqlCommand command = new SqlCommand("DELETEUSER", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add("@MAILID", SqlDbType.VarChar);
            command.Parameters["@MAILID"].Value = mailId;
            command.ExecuteNonQuery();
            //Parameter
            //string deleteUser = "DELETE FROM USERDETAIL where MAILID = @mailId";
            //SqlCommand command = new SqlCommand(deleteUser, connection);
            //command.Parameters.Add("@MAILID",SqlDbType.VarChar);
            //command.Parameters["@MAILID"].Value = mailId;
            //command.Parameters.Remove(mailId);
            //command.ExecuteNonQuery();

            //DataAdapter
            //string deleteUser = "DELETE FROM USERDETAIL WHERE USERNAME = '" + mailId + "';";
            //SqlDataAdapter adapter = new SqlDataAdapter();
            //adapter.DeleteCommand = connection.CreateCommand();
            //adapter.DeleteCommand.CommandText = deleteUser;
            //adapter.DeleteCommand.ExecuteNonQuery();
        }

        //public void DisplayProcedureList(SqlConnection connection)
        //{
        //    string query = @"SELECT SPECIFIC_NAME FROM sample.information_schema.routines WHERE routine_type = 'PROCEDURE'";
        //    SqlCommand sqlCommand = new SqlCommand(query,connection);
        //    try
        //    {
        //        SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
        //        while (sqlDataReader.Read())
        //        {
        //            Console.WriteLine(sqlDataReader["SPECIFIC NAME"].ToString());
        //        }
        //    }
        //    catch(Exception Ex)
        //    {
        //        Console.WriteLine(Ex.Message);
        //    }
        //}


    }
}
